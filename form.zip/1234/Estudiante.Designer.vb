﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Estudiante
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.PracticasProfesionalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListadoDePrácticasProfesionalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.panelFormularioPostulacion = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PanelFormulario = New System.Windows.Forms.Panel()
        Me.BTNEnviarFormulario = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TxtDescripcionEst = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtRequisitosEst = New System.Windows.Forms.TextBox()
        Me.TxtHabilidadesEst = New System.Windows.Forms.TextBox()
        Me.TxtCorreoEst = New System.Windows.Forms.TextBox()
        Me.TxtNombreEst = New System.Windows.Forms.TextBox()
        Me.MenuStrip2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFormularioPostulacion.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelFormulario.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(28, 28)
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 38)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1069, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip2.ImageScalingSize = New System.Drawing.Size(28, 28)
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PracticasProfesionalesToolStripMenuItem, Me.AyudaToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1069, 38)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'PracticasProfesionalesToolStripMenuItem
        '
        Me.PracticasProfesionalesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListadoDePrácticasProfesionalesToolStripMenuItem})
        Me.PracticasProfesionalesToolStripMenuItem.Image = Global._1234.My.Resources.Resources.practicas
        Me.PracticasProfesionalesToolStripMenuItem.Name = "PracticasProfesionalesToolStripMenuItem"
        Me.PracticasProfesionalesToolStripMenuItem.Size = New System.Drawing.Size(191, 34)
        Me.PracticasProfesionalesToolStripMenuItem.Text = "Ofertas de P.P"
        '
        'ListadoDePrácticasProfesionalesToolStripMenuItem
        '
        Me.ListadoDePrácticasProfesionalesToolStripMenuItem.Image = Global._1234.My.Resources.Resources.postular
        Me.ListadoDePrácticasProfesionalesToolStripMenuItem.Name = "ListadoDePrácticasProfesionalesToolStripMenuItem"
        Me.ListadoDePrácticasProfesionalesToolStripMenuItem.Size = New System.Drawing.Size(270, 40)
        Me.ListadoDePrácticasProfesionalesToolStripMenuItem.Text = "Postular Oferta"
        '
        'AyudaToolStripMenuItem
        '
        Me.AyudaToolStripMenuItem.Image = Global._1234.My.Resources.Resources.Ayuda
        Me.AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
        Me.AyudaToolStripMenuItem.Size = New System.Drawing.Size(118, 34)
        Me.AyudaToolStripMenuItem.Text = "Ayuda"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(310, 392)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(27, 25)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "..."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(310, 345)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(87, 25)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Nombre:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(508, 252)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 25)
        Me.Label6.TabIndex = 27
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(537, 218)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(304, 25)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Carrera: LIC.ING.SIST.Y COMP.."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(537, 164)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(453, 25)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Facultad: Ingenieria de Sistemas Computacionales"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(537, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(155, 25)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Sede: Veraguas"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(310, 435)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 25)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Email:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(310, 298)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 25)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Estudiante"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global._1234.My.Resources.Resources.estudiante
        Me.PictureBox1.Location = New System.Drawing.Point(315, 101)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(205, 158)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 21
        Me.PictureBox1.TabStop = False
        '
        'panelFormularioPostulacion
        '
        Me.panelFormularioPostulacion.Controls.Add(Me.Button1)
        Me.panelFormularioPostulacion.Controls.Add(Me.DataGridView1)
        Me.panelFormularioPostulacion.Controls.Add(Me.Label9)
        Me.panelFormularioPostulacion.Location = New System.Drawing.Point(214, 75)
        Me.panelFormularioPostulacion.Name = "panelFormularioPostulacion"
        Me.panelFormularioPostulacion.Size = New System.Drawing.Size(807, 494)
        Me.panelFormularioPostulacion.TabIndex = 30
        Me.panelFormularioPostulacion.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(282, 414)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(208, 46)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "LLenar el formulario"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(40, 76)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 72
        Me.DataGridView1.RowTemplate.Height = 31
        Me.DataGridView1.Size = New System.Drawing.Size(714, 319)
        Me.DataGridView1.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.142858!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(19, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(157, 25)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Postular Oferta"
        '
        'PanelFormulario
        '
        Me.PanelFormulario.Controls.Add(Me.BTNEnviarFormulario)
        Me.PanelFormulario.Controls.Add(Me.Label15)
        Me.PanelFormulario.Controls.Add(Me.TxtDescripcionEst)
        Me.PanelFormulario.Controls.Add(Me.Label14)
        Me.PanelFormulario.Controls.Add(Me.Label13)
        Me.PanelFormulario.Controls.Add(Me.Label12)
        Me.PanelFormulario.Controls.Add(Me.Label11)
        Me.PanelFormulario.Controls.Add(Me.Label10)
        Me.PanelFormulario.Controls.Add(Me.TxtRequisitosEst)
        Me.PanelFormulario.Controls.Add(Me.TxtHabilidadesEst)
        Me.PanelFormulario.Controls.Add(Me.TxtCorreoEst)
        Me.PanelFormulario.Controls.Add(Me.TxtNombreEst)
        Me.PanelFormulario.Location = New System.Drawing.Point(214, 65)
        Me.PanelFormulario.Name = "PanelFormulario"
        Me.PanelFormulario.Size = New System.Drawing.Size(819, 547)
        Me.PanelFormulario.TabIndex = 31
        Me.PanelFormulario.Visible = False
        '
        'BTNEnviarFormulario
        '
        Me.BTNEnviarFormulario.Font = New System.Drawing.Font("Arial Rounded MT Bold", 8.142858!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNEnviarFormulario.Location = New System.Drawing.Point(292, 459)
        Me.BTNEnviarFormulario.Name = "BTNEnviarFormulario"
        Me.BTNEnviarFormulario.Size = New System.Drawing.Size(191, 40)
        Me.BTNEnviarFormulario.TabIndex = 20
        Me.BTNEnviarFormulario.Text = "Enviar Formulario"
        Me.BTNEnviarFormulario.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(57, 210)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(114, 25)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Descripción"
        '
        'TxtDescripcionEst
        '
        Me.TxtDescripcionEst.Location = New System.Drawing.Point(62, 249)
        Me.TxtDescripcionEst.Name = "TxtDescripcionEst"
        Me.TxtDescripcionEst.Size = New System.Drawing.Size(664, 29)
        Me.TxtDescripcionEst.TabIndex = 18
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.142858!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(57, 30)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(361, 25)
        Me.Label14.TabIndex = 17
        Me.Label14.Text = "Formulario para Práctica Profesional"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(57, 340)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(102, 25)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "Requisitos"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(549, 100)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(114, 25)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Habilidades"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(306, 100)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 25)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Correo"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(57, 100)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(81, 25)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Nombre"
        '
        'TxtRequisitosEst
        '
        Me.TxtRequisitosEst.Location = New System.Drawing.Point(62, 383)
        Me.TxtRequisitosEst.Name = "TxtRequisitosEst"
        Me.TxtRequisitosEst.Size = New System.Drawing.Size(172, 29)
        Me.TxtRequisitosEst.TabIndex = 12
        '
        'TxtHabilidadesEst
        '
        Me.TxtHabilidadesEst.Location = New System.Drawing.Point(554, 140)
        Me.TxtHabilidadesEst.Name = "TxtHabilidadesEst"
        Me.TxtHabilidadesEst.Size = New System.Drawing.Size(172, 29)
        Me.TxtHabilidadesEst.TabIndex = 11
        '
        'TxtCorreoEst
        '
        Me.TxtCorreoEst.Location = New System.Drawing.Point(311, 140)
        Me.TxtCorreoEst.Name = "TxtCorreoEst"
        Me.TxtCorreoEst.Size = New System.Drawing.Size(172, 29)
        Me.TxtCorreoEst.TabIndex = 10
        '
        'TxtNombreEst
        '
        Me.TxtNombreEst.Location = New System.Drawing.Point(62, 137)
        Me.TxtNombreEst.Name = "TxtNombreEst"
        Me.TxtNombreEst.Size = New System.Drawing.Size(177, 29)
        Me.TxtNombreEst.TabIndex = 9
        '
        'Estudiante
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1069, 648)
        Me.Controls.Add(Me.PanelFormulario)
        Me.Controls.Add(Me.panelFormularioPostulacion)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Estudiante"
        Me.Text = "Estudiante"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFormularioPostulacion.ResumeLayout(False)
        Me.panelFormularioPostulacion.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelFormulario.ResumeLayout(False)
        Me.PanelFormulario.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents PracticasProfesionalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ListadoDePrácticasProfesionalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents panelFormularioPostulacion As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents PanelFormulario As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents BTNEnviarFormulario As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents TxtDescripcionEst As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TxtRequisitosEst As TextBox
    Friend WithEvents TxtHabilidadesEst As TextBox
    Friend WithEvents TxtCorreoEst As TextBox
    Friend WithEvents TxtNombreEst As TextBox
End Class
