﻿Public Class Form1
    Private Sub SolicitudesDePracProfeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SolicitudesDePracProfeToolStripMenuItem.Click
        ' Si el panel está visible, lo oculta; si está oculto, lo muestra
        Panel1.Visible = Not Panel1.Visible
    End Sub

    Private Sub PublicacionesDePracticasProfesionalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PublicacionesDePracticasProfesionalesToolStripMenuItem.Click
        Panel2.Visible = Not Panel2.Visible
    End Sub
End Class
